from setuptools import setup

setup(
    name='py-scurve',
    version='1.0',
)
